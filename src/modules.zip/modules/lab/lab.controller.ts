import {
  Request,
  Response,
  NextFunction,
} from 'express';

import { LabService } from './lab.service.js';

import {
  CreateLabOrderDTO,
  RecordLabResultsDTO,
  RejectSampleDTO,
  GetLabOrdersQueryDTO,
  AmendResultsDTO,
  RepeatTestDTO,
  AccessionSpecimenDTO,
  TransitionSpecimenDTO, SpecimenStatus, CreateReferenceRangeDTO, CriticalAlertStatus, AnalyzerResultDTO,
} from './lab.types.js';

import { AuthRequest } from '../../middlewares/auth.middleware.js';

/* =========================================================
   CONTROLLER
========================================================= */

export class LabController {
  private static getAuthContext(
    req: Request
  ) {
    const authReq =
      req as AuthRequest;

    const userId =
      authReq.user?._id ||
      authReq.user?.accountId ||
      authReq.account?.accountId;

    const hospitalId =
      authReq.user?.hospitalId ||
      authReq.user?.accountId ||
      authReq.account?.accountId;

    if (!userId || !hospitalId) {
      const error = new Error(
        'Authentication context is missing.'
      ) as Error & {
        statusCode?: number;
      };

      error.statusCode = 401;

      throw error;
    }

    return {
      userId,
      hospitalId,
    };
  }

  /* =========================================================
     CREATE
  ========================================================= */

  static async create(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const order =
        await LabService.createOrder(
          hospitalId,
          userId,
          req.body as CreateLabOrderDTO
        );

      res.status(201).json({
        success: true,
        data: order,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     LIST / WORKLIST
  ========================================================= */

  static async list(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        hospitalId,
      } = LabController.getAuthContext(req);

      const result =
        await LabService.getOrders(
          hospitalId,
          req.query as unknown as GetLabOrdersQueryDTO
        );

      res.status(200).json({
        success: true,
        ...result,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     GET BY ID
  ========================================================= */

  static async getById(
    req: Request<{ id: string }>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        hospitalId,
      } = LabController.getAuthContext(req);

      const order =
        await LabService.getOrderById(
          hospitalId,
          req.params.id
        );

      res.status(200).json({
        success: true,
        data: order,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     COLLECT SAMPLE
  ========================================================= */

  static async collectSample(
    req: Request<{ id: string }>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const updated =
        await LabService.collectSample(
          hospitalId,
          req.params.id,
          userId
        );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     ACCESSION SPECIMEN
  ========================================================= */

  static async accessionSpecimen(
    req: Request<
      { id: string },
      unknown,
      AccessionSpecimenDTO
    >,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const updated =
        await LabService.accessionSpecimen(
          hospitalId,
          req.params.id,
          userId,
          req.body || {}
        );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     REJECT SAMPLE
  ========================================================= */

  static async rejectSample(
    req: Request<
      { id: string },
      unknown,
      RejectSampleDTO
    >,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const updated =
        await LabService.rejectSample(
          hospitalId,
          req.params.id,
          userId,
          req.body
        );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     RECOLLECT SAMPLE
  ========================================================= */

  static async recollectSample(
    req: Request<{ id: string }>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const updated =
        await LabService.recollectSample(
          hospitalId,
          req.params.id,
          userId
        );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     PRICING CATALOGUES
  ========================================================= */

  static async pricingCatalogues(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { hospitalId } = LabController.getAuthContext(req);
      const items = await LabService.getPricingCatalogues(
        hospitalId,
        typeof req.query.testName === 'string' ? req.query.testName : undefined
      );

      res.status(200).json({
        success: true,
        data: items,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     BILLING
  ========================================================= */

  static async captureBilling(
    req: Request<{ id: string }>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { userId, hospitalId } = LabController.getAuthContext(req);

      const updated = await LabService.captureBilling(
        hospitalId,
        req.params.id,
        userId
      );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     RECORD RESULTS
  ========================================================= */

  static async submitResults(
    req: Request<
      { id: string },
      unknown,
      RecordLabResultsDTO
    >,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const updated =
        await LabService.recordResults(
          hospitalId,
          req.params.id,
          userId,
          req.body
        );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     VERIFY RESULTS
  ========================================================= */

  static async verifyResults(
    req: Request<{ id: string }>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const updated =
        await LabService.verifyResults(
          hospitalId,
          req.params.id,
          userId
        );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     AUTHORIZE RESULTS
  ========================================================= */

  static async authorizeResults(
    req: Request<{ id: string }>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const updated =
        await LabService.authorizeResults(
          hospitalId,
          req.params.id,
          userId
        );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     AMEND RESULTS
  ========================================================= */

  static async amendResults(
    req: Request<
      { id: string },
      unknown,
      AmendResultsDTO
    >,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const updated =
        await LabService.amendResults(
          hospitalId,
          req.params.id,
          userId,
          req.body
        );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /* =========================================================
     REPEAT TEST
  ========================================================= */

  static async repeatTest(
    req: Request<
      { id: string },
      unknown,
      RepeatTestDTO
    >,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const {
        userId,
        hospitalId,
      } = LabController.getAuthContext(req);

      const updated =
        await LabService.repeatTest(
          hospitalId,
          req.params.id,
          userId,
          req.body
        );

      res.status(200).json({
        success: true,
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }
  static async specimen(
    req: Request<{ id: string }>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { hospitalId } = LabController.getAuthContext(req);
      const data = await LabService.getSpecimen(hospitalId, req.params.id);
      res.status(200).json({ success: true, data });
    } catch (error) { next(error); }
  }

  static async transitionSpecimen(
    req: Request<{ id: string }, unknown, TransitionSpecimenDTO>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { userId, hospitalId } = LabController.getAuthContext(req);
      const target = String(req.body.status || req.query.status || '').toUpperCase() as SpecimenStatus;
      const data = await LabService.transitionSpecimen(hospitalId, req.params.id, userId, target, req.body);
      res.status(200).json({ success: true, data });
    } catch (error) { next(error); }
  }

  static async processSpecimen(
    req: Request<{ id: string }, unknown, TransitionSpecimenDTO>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { userId, hospitalId } = LabController.getAuthContext(req);
      const data = await LabService.processSpecimen(hospitalId, req.params.id, userId, req.body);
      res.status(200).json({ success: true, data });
    } catch (error) { next(error); }
  }

  static async createReferenceRange(
    req: Request<any, any, CreateReferenceRangeDTO>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { hospitalId } = LabController.getAuthContext(req);
      const data = await LabService.createReferenceRange(hospitalId, req.body);
      res.status(201).json({ success: true, data });
    } catch (error) { next(error); }
  }

  static async listReferenceRanges(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { hospitalId } = LabController.getAuthContext(req);
      const data = await LabService.listReferenceRanges(hospitalId, typeof req.query.parameterName === 'string' ? req.query.parameterName : undefined);
      res.status(200).json({ success: true, data });
    } catch (error) { next(error); }
  }

  static async listCriticalAlerts(
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { hospitalId } = LabController.getAuthContext(req);
      const status = typeof req.query.status === 'string' ? req.query.status as CriticalAlertStatus : undefined;
      const data = await LabService.listCriticalAlerts(hospitalId, status);
      res.status(200).json({ success: true, data });
    } catch (error) { next(error); }
  }

  static async acknowledgeCriticalAlert(
    req: Request<{ id: string }>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { hospitalId, userId } = LabController.getAuthContext(req);
      const data = await LabService.acknowledgeCriticalAlert(hospitalId, req.params.id, userId);
      res.status(200).json({ success: true, data });
    } catch (error) { next(error); }
  }

  static async ingestAnalyzerResult(
    req: Request<any, any, AnalyzerResultDTO>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { hospitalId, userId } = LabController.getAuthContext(req);
      const data = await LabService.ingestAnalyzerResult(hospitalId, userId, req.body);
      res.status(200).json({ success: true, data });
    } catch (error) { next(error); }
  }

  static async buildAnalyzerOrderMessage(
    req: Request<{ id: string }>,
    res: Response,
    next: NextFunction
  ): Promise<void> {
    try {
      const { hospitalId } = LabController.getAuthContext(req);
      const protocol = (String(req.body?.protocol || req.query.protocol || 'HL7').toUpperCase() as 'HL7' | 'ASTM');
      const data = await LabService.buildAnalyzerOrderMessage(hospitalId, req.params.id, protocol);
      res.status(200).json({ success: true, data, protocol });
    } catch (error) { next(error); }
  }

}