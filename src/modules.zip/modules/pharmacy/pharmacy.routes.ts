import { Router } from 'express';
import { PharmacyController } from './pharmacy.controller.js';
import { authenticate } from '../../middlewares/auth.middleware.js';

const router = Router();

router.use(authenticate);

router.post('/inventory', PharmacyController.createItem);
router.get('/inventory', PharmacyController.listInventory);
router.get('/inventory/:id', PharmacyController.getItemById);
router.patch('/inventory/:id/stock', PharmacyController.adjustStock);
router.get('/inventory/:id/ledger', PharmacyController.inventoryLedger);

router.get('/prescribers', PharmacyController.listPrescribers);
router.post('/prescriptions', PharmacyController.createPrescription);
router.get('/prescriptions', PharmacyController.listPrescriptions);
router.get('/prescriptions/:id', PharmacyController.getPrescriptionById);
router.post('/prescriptions/:id/screen', PharmacyController.screenPrescription);
router.post('/prescriptions/:id/approve', PharmacyController.approvePrescription);

router.post('/dispense', PharmacyController.dispenseDrugs);
router.get('/dispense', PharmacyController.listDispenseRecords);
router.post('/dispense/:id/retry-billing', PharmacyController.retryBilling);

router.post('/formulary', PharmacyController.createFormulary);
router.get('/formulary', PharmacyController.listFormulary);

export default router;
